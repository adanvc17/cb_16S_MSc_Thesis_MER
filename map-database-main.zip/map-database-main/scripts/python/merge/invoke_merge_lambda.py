import json
from concurrent.futures import ThreadPoolExecutor, as_completed

import boto3
from tqdm import tqdm

from src.s3_utils.exists import object_exists

bucket = "map-database"
s3 = boto3.client("s3")


def main():
    source_keys = get_keys()
    print(f"Found {len(source_keys)} files")

    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {
            pool.submit(invoke_lambda, chunk, str(id_).zfill(3)): id_ for id_, chunk in enumerate(chunked(source_keys))
        }

        for future in tqdm(as_completed(futures), total=len(futures)):
            id_, error = future.result()
            if error:
                tqdm.write(f"FAILED {id_}: {error}")


def chunked(data: list, size: int = 100):
    for i in range(0, len(data), size):
        yield data[i : i + size]


def get_keys():
    prefix = "fasta-files/"

    paginator = s3.get_paginator("list_objects_v2")
    source_keys = []
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            file_name = obj["Key"]
            if not file_name.endswith(".fasta"):
                continue

            source_keys.append(file_name)

    source_keys.sort()
    return source_keys


def invoke_lambda(keys: list[str], batch_id: str):
    key = f"combined/batch-{batch_id}.fasta"
    if object_exists(bucket, key):
        tqdm.write(f"skipping batch {key}, already processed")
        return batch_id, None

    client = boto3.client("lambda")
    tqdm.write(f"invoking lambda for batch {batch_id}, {keys[:3]} ...")
    client.invoke(
        FunctionName="merge-fasta-files",
        Payload=json.dumps(
            {
                "keys": keys,
                "id": batch_id,
            },
        ),
    )


if __name__ == "__main__":
    main()
