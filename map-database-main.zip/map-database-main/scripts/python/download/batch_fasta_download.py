import os
import sys
from pathlib import Path

import boto3

from src.download_fasta.download import download_fasta
from src.s3_utils.exists import object_exists

s3 = boto3.client("s3")
bucket = os.environ.get("S3_BUCKET", "map-database")

run_map: dict[str, set[str]] = {}
map_file = "taxon_all_amplicon_BioSamples_Runs_MAP_AR3_4.txt"
with open(map_file) as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        id_, run = line.split(",")
        run_map.setdefault(id_, set()).add(run)


def files_exist(id_: str) -> bool:
    runs = run_map.get(id_, set())
    return bool(runs) and any(
        object_exists(bucket, key) for run in runs for key in (f"{run}.fasta", f"{run}_merged.fasta")
    )


def resolve_ids(path: str) -> str:
    if path.startswith("s3://"):
        parts = path.removeprefix("s3://").split("/", 1)
        bucket_name, key = parts[0], parts[1]
        local = f"/tmp/{key.replace('/', '_')}"
        s3.download_file(bucket_name, key, local)
        return local
    return path


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <ids_file_or_s3_uri>", file=sys.stderr)
        sys.exit(1)

    ids = Path(resolve_ids(sys.argv[1])).read_text().strip().splitlines()
    total = len(ids)

    for i, id_ in enumerate(ids, 1):
        print(f"[{i}/{total}] {id_} ...", end=" ", flush=True)
        if files_exist(id_):
            print("skipped (already in S3)")
            continue
        try:
            download_fasta(id_)
            print("done")
        except Exception as e:  # noqa: BLE001 - keep going; log and continue with next id
            print(f"FAILED: {e}")


if __name__ == "__main__":
    main()
