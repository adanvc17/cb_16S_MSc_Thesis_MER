import json
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import boto3
import tqdm
from botocore.exceptions import ClientError

from src.s3_utils.exists import object_exists

BACKOFF = [5, 10, 30, 60]


lambda_client = boto3.client("lambda", region_name="eu-west-1")
s3_client = boto3.client("s3")
bucket = "map-database"


def main():
    """Invoke the map-database Lambda once per sample id, skipping ids whose
    FASTA already exists in S3, and write each response to results/<id>.json."""
    run_map: dict[str, set[str]] = defaultdict(set)
    with open("taxon_all_amplicon_BioSamples_Runs_MAP_AR3_4.txt") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            id_, run = line.split(",")
            run_map[id_].add(run)

    ids = Path("taxon_all_amplicon_samples_MAP_AR3_4.txt").read_text().strip().splitlines()
    out_dir = Path("results")
    out_dir.mkdir(exist_ok=True)

    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = {pool.submit(invoke, id_, run_map): id_ for id_ in ids}
        for future in tqdm.tqdm(as_completed(futures), total=len(futures), desc="Invoking"):
            id_, body = future.result()
            if body is not None:
                (out_dir / f"{id_}.json").write_text(json.dumps(body, indent=2))


def invoke(id_: str, run_map) -> tuple[str, dict | None]:
    if files_exist(id_, run_map):
        return id_, None

    payload = json.dumps({"id": id_}).encode()
    for attempt, delay in enumerate([0] + BACKOFF):
        if attempt > 0:
            time.sleep(delay)

        try:
            response = lambda_client.invoke(FunctionName="map-database", Payload=payload)
            body = json.loads(response["Payload"].read())
            if body.get("statusCode") in (200, 404):
                return id_, body
        except ClientError:
            pass

    return id_, {"statusCode": 500, "body": "failed after all retries"}


def files_exist(id_: str, run_map) -> bool:
    return any(
        object_exists(bucket, key, client=s3_client)
        for run in run_map[id_]
        for key in (f"{run}.fasta", f"{run}_merged.fasta")
    )


if __name__ == "__main__":
    main()
