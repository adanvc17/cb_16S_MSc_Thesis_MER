import sys
from pathlib import Path

import boto3

CLUSTER = "map-database"
TASK_DEF = "map-database:2"
SUBNETS = ["subnet-0ae393abd1722fb12", "subnet-005ac7f5fc836b38c", "subnet-05481e5c9bcce4835"]
BUCKET = "map-database"
CHUNKS_DIR = Path("/home/laurens/Programming/danito/map-database/chunks")

ecs = boto3.client("ecs")

pattern = sys.argv[1] if len(sys.argv) > 1 else "retry_*.txt"
chunks = sorted(CHUNKS_DIR.glob(pattern))
if not chunks:
    print(f"No chunks matched: {pattern}")
    sys.exit(1)

print(f"Submitting {len(chunks)} chunks...")
for chunk in chunks:
    s3_uri = f"s3://{BUCKET}/chunks/{chunk.name}"
    response = ecs.run_task(
        cluster=CLUSTER,
        launchType="FARGATE",
        taskDefinition=TASK_DEF,
        networkConfiguration={
            "awsvpcConfiguration": {
                "subnets": SUBNETS,
                "assignPublicIp": "ENABLED",
            }
        },
        overrides={
            "containerOverrides": [
                {
                    "name": "app",
                    "command": ["batch_fasta_download.py", s3_uri],
                }
            ]
        },
    )
    tasks = response.get("tasks", [])
    if tasks:
        task_id = tasks[0]["taskArn"].split("/")[-1]
        print(f"OK: {chunk.name} -> {task_id}")
    else:
        print(f"FAIL: {chunk.name} ({response.get('failures', [{}])[0].get('reason', 'unknown')})")
