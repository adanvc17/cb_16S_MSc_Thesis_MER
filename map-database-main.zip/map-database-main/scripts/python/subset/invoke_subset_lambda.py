"""
Invoke the subset-fasta Lambda for every subset list in
s3://map-database/retained_blasts, one invocation per file, using a
thread pool of 5 workers. Logs the result of each invocation.
"""

import json
import os
import random
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from tqdm import tqdm

from src.s3_utils.exists import object_exists

REGION = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "eu-west-1"))
BUCKET = "map-database"
SUBSET_PREFIX = "retained_blasts/"
FASTA_PREFIX = "combined/"
OUTPUT_PREFIX = "subset-outputs/"
FUNCTION_NAME = "subset-fasta-ba56b75"
MAX_WORKERS = 10
MAX_ATTEMPTS = 30
BACKOFF_BASE = 1.0
BACKOFF_CAP = 30.0
BACKOFF_JITTER = 0.5
THROTTLE_CODES = {"ThrottlingException", "TooManyRequestsException"}

s3 = boto3.client("s3", region_name=REGION)
lambda_client = boto3.client(
    "lambda",
    region_name=REGION,
    config=Config(
        connect_timeout=10,
        read_timeout=910,  # comfortably above your Lambda's configured timeout (max 900s)
        retries={"max_attempts": 0},  # disable botocore's built-in retries entirely
    ),
)


def list_subset_keys():
    paginator = s3.get_paginator("list_objects_v2")
    keys = []
    for page in paginator.paginate(Bucket=BUCKET, Prefix=SUBSET_PREFIX):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith("_filtered_clean.csv"):
                keys.append(obj["Key"])
    keys.sort()
    return keys


def sleep_til_available(attempt: int) -> None:
    """Exponential backoff with jitter so a throttled lambda gets breathing room."""
    delay = min(BACKOFF_BASE * (2**attempt), BACKOFF_CAP) + random.uniform(0, BACKOFF_JITTER)
    time.sleep(delay)


def is_throttle(error: ClientError) -> bool:
    status = error.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
    code = error.response.get("Error", {}).get("Code", "")
    return status == 429 or code in THROTTLE_CODES


def invoke_one(subset_key: str) -> tuple[str, str]:
    event = build_event(subset_key)
    if event is None:
        return subset_key, f"SKIPPED: {subset_key!r} does not match *_filtered_clean.csv"

    last_error = None
    for attempt in range(MAX_ATTEMPTS):
        try:
            tqdm.write(f"invoking {subset_key}")
            resp = lambda_client.invoke(
                FunctionName=FUNCTION_NAME,
                InvocationType="RequestResponse",
                Payload=json.dumps(event),
            )
            payload = resp["Payload"].read().decode()
            status = resp["StatusCode"]
            if resp.get("FunctionError"):
                return subset_key, f"ERROR(status={status}): {payload}"

            result = json.loads(payload)
            return subset_key, f"OK(status={status}, count={result.get('count')}, output={result.get('output')})"
        except ClientError as e:
            if not is_throttle(e):
                return subset_key, f"ERROR: {e}"
            last_error = e
            tqdm.write(f"[{subset_key}] throttled on attempt {attempt + 1}, sleeping ...")
            sleep_til_available(attempt)

    return subset_key, f"FAILED after {MAX_ATTEMPTS} attempts: {last_error}"


def build_event(subset_key: str) -> dict | None:
    """Pair a retained_blasts subset file with its FASTA source file."""
    filename = os.path.basename(subset_key)
    if not filename.endswith("_filtered_clean.csv"):
        return None

    batch_id = filename[: -len("_filtered_clean.csv")]
    return {
        "fasta": f"s3://{BUCKET}/{FASTA_PREFIX}{batch_id}.fasta",
        "subset": f"s3://{BUCKET}/{subset_key}",
    }


def output_key_for(subset_key: str) -> str:
    """subset-outputs/<batch>.subset.fasta for a *_filtered_clean.csv key."""
    batch_id = os.path.basename(subset_key)[: -len("_filtered_clean.csv")]
    return f"{OUTPUT_PREFIX}{batch_id}.subset.fasta"


def output_exists(subset_key: str) -> bool:
    """True if the lambda's output object already exists in S3."""
    return object_exists(BUCKET, output_key_for(subset_key))


def main():
    keys = sorted(list_subset_keys(), reverse=True)
    tqdm.write(f"Found {len(keys)} subset files in s3://{BUCKET}/{SUBSET_PREFIX}")

    pending = [k for k in keys if not output_exists(k)]
    skipped = [k for k in keys if output_exists(k)]
    # for key in skipped:
    #     tqdm.write(f"[{key}] SKIPPED: {output_key_for(key)} already exists")

    for key in pending:
        tqdm.write(f"[{key}] PENDING: {output_key_for(key)}")

    tqdm.write(f"Found {len(keys)} subset files; {len(skipped)} already processed, {len(pending)} pending")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(invoke_one, key): key for key in pending}
        for future in tqdm(as_completed(futures), total=len(futures)):
            key, result = future.result()
            tqdm.write(f"[{key}] {result}")


if __name__ == "__main__":
    main()
