"""
One-shot ECS Fargate task for a single subset-fasta job: filter one FASTA
file from S3 against one subset list, and write the result to S3. The subset
key is passed via the S3_SUBSET_KEY env var (set by an ECS container override
at run-task time).

Env vars:
    S3_BUCKET      bucket holding both inputs and outputs (required)
    S3_SUBSET_KEY  key of the *_filtered_clean.csv subset to process (required)
    FASTA_PREFIX   where the batch FASTA files live (default combined/)
    OUTPUT_PREFIX  where the subset FASTA files are written (default subset-outputs/)
"""

import os

import boto3

from dockerfiles.subset_lambda.subset_fasta import iter_text_lines, read_present_ids, upload_filtered_fasta
from src.s3_utils.exists import object_exists
from src.subset.fasta import fasta_records

BUCKET = os.environ["S3_BUCKET"]
SUBSET_KEY = os.environ["S3_SUBSET_KEY"]
FASTA_PREFIX = os.environ.get("FASTA_PREFIX", "combined/")
OUTPUT_PREFIX = os.environ.get("OUTPUT_PREFIX", "subset-outputs/")

s3 = boto3.client("s3")


def main() -> None:
    output_key = output_key_for(SUBSET_KEY)
    if object_exists(BUCKET, output_key):
        print(f"{SUBSET_KEY}: skipped (output exists)", flush=True)
        return

    fasta_key = f"{FASTA_PREFIX}{os.path.basename(SUBSET_KEY).removesuffix('_filtered_clean.csv')}.fasta"

    wanted_ids = read_present_ids(BUCKET, SUBSET_KEY)
    fasta_body = s3.get_object(Bucket=BUCKET, Key=fasta_key)["Body"]
    count = upload_filtered_fasta(
        BUCKET,
        output_key,
        fasta_records(iter_text_lines(fasta_body)),
        wanted_ids,
    )

    print(f"{SUBSET_KEY}: {count} records -> s3://{BUCKET}/{output_key}", flush=True)
    print("Done", flush=True)


def output_key_for(subset_key: str) -> str:
    batch = os.path.basename(subset_key).removesuffix("_filtered_clean.csv")
    return f"{OUTPUT_PREFIX}{batch}.subset.fasta"


if __name__ == "__main__":
    main()
