from pathlib import Path

FASTA_PATH_TEMPLATE = "/tmp/subset-outputs/batch-{}.subset.fasta"


def main():
    for blast in sorted(Path("./retained_blasts").glob("*.csv")):
        batch_id = str(blast.name).lstrip("batch-")[:3]

        ids_1 = set()
        for line in blast.open():
            (_, id_, *_) = line.split(",")
            ids_1.add(id_)

        fasta_subset = Path(FASTA_PATH_TEMPLATE.format(batch_id))

        ids_2 = set()
        for a, _ in fasta_pairs(fasta_subset.open()):
            id_, *_ = a.split(" ", 1)
            id_ = id_.lstrip(">")
            ids_2.add(id_)

        print(batch_id, len(ids_1), len(ids_2), ids_1 == ids_2)


def fasta_pairs(f):
    for header, seq in zip(f, f):
        yield header.strip(), seq.strip()


if __name__ == "__main__":
    main()
