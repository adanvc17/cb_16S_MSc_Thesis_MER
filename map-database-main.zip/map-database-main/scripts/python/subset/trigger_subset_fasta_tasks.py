"""
Launch one Fargate task per *_filtered_clean.csv under retained_blasts/, each
processing a single subset against its combined/ FASTA file. Uses a thread
pool to bound concurrent tasks (MAX_WORKERS). Skips batches whose output
already exists in subset-outputs/.

Usage:
    python scripts/python/subset/trigger_subset_fasta_tasks.py
"""

import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import boto3
from botocore.exceptions import ClientError
from tqdm import tqdm

from src.s3_utils.exists import object_exists

REGION = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "eu-west-1"))
BUCKET = "map-database"
SUBSET_PREFIX = "retained_blasts/"
OUTPUT_PREFIX = "subset-outputs/"
CLUSTER = "file-processor-cluster-804bbb9"
TASK_DEFINITION = "subset-fasta-fargate"
MAX_WORKERS = 5
POLL_SECONDS = 30
MAX_LAUNCH_ATTEMPTS = 20
LAUNCH_BACKOFF_BASE = 10.0
LAUNCH_BACKOFF_CAP = 120.0

ecs = boto3.client("ecs", region_name=REGION)
ec2 = boto3.client("ec2", region_name=REGION)
s3 = boto3.client("s3", region_name=REGION)


def list_subset_keys():
    paginator = s3.get_paginator("list_objects_v2")
    keys = []
    for page in paginator.paginate(Bucket=BUCKET, Prefix=SUBSET_PREFIX):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith("_filtered_clean.csv"):
                keys.append(obj["Key"])
    keys.sort()
    return keys


def output_key_for(subset_key: str) -> str:
    batch = os.path.basename(subset_key).removesuffix("_filtered_clean.csv")
    return f"{OUTPUT_PREFIX}{batch}.subset.fasta"


def already_done(subset_key: str) -> bool:
    return object_exists(BUCKET, output_key_for(subset_key))


def network_configuration() -> dict:
    default_vpc = ec2.describe_vpcs(Filters=[{"Name": "isDefault", "Values": ["true"]}])["Vpcs"][0]["VpcId"]
    subnets = ec2.describe_subnets(Filters=[{"Name": "vpc-id", "Values": [default_vpc]}])["Subnets"]
    security_groups = ec2.describe_security_groups(Filters=[{"Name": "vpc-id", "Values": [default_vpc]}])[
        "SecurityGroups"
    ]
    sg = next(sg for sg in security_groups if sg["GroupName"].startswith("file-processor-sg"))

    return {
        "awsvpcConfiguration": {
            "subnets": [s["SubnetId"] for s in subnets if s["MapPublicIpOnLaunch"]],
            "securityGroups": [sg["GroupId"]],
            "assignPublicIp": "ENABLED",
        }
    }


def launch_task(subset_key: str) -> str:
    """Launch one Fargate task, retrying with backoff on launch throttling."""
    for attempt in range(1, MAX_LAUNCH_ATTEMPTS + 1):
        try:
            resp = ecs.run_task(
                cluster=CLUSTER,
                taskDefinition=TASK_DEFINITION,
                launchType="FARGATE",
                networkConfiguration=network_configuration(),
                overrides={
                    "containerOverrides": [
                        {
                            "name": "subset-fasta",
                            "environment": [{"name": "S3_SUBSET_KEY", "value": subset_key}],
                        }
                    ]
                },
            )
        except (ClientError, ecs.exceptions.ClientException) as e:
            if attempt == MAX_LAUNCH_ATTEMPTS:
                return f"{subset_key}: LAUNCH ERROR after {attempt} attempts: {e}"
            delay = min(LAUNCH_BACKOFF_BASE * (2 ** (attempt - 1)), LAUNCH_BACKOFF_CAP)
            tqdm.write(f"[{subset_key}] launch throttled (attempt {attempt}), retrying in {delay:.0f}s")
            time.sleep(delay)
            continue

        if resp.get("failures"):
            reason = resp["failures"][0]["reason"]
            if any(word in reason.lower() for word in ["limit", "vcp", "throttl", "rate"]):
                if attempt == MAX_LAUNCH_ATTEMPTS:
                    return f"{subset_key}: LAUNCH FAILED after {attempt} attempts: {reason}"
                delay = min(LAUNCH_BACKOFF_BASE * (2 ** (attempt - 1)), LAUNCH_BACKOFF_CAP)
                tqdm.write(f"[{subset_key}] {reason} (attempt {attempt}), retry in {delay:.0f}s")
                time.sleep(delay)
                continue
            return f"{subset_key}: LAUNCH FAILED: {reason}"

        return resp["tasks"][0]["taskArn"]
    return f"{subset_key}: LAUNCH FAILED: exhausted attempts"


def run_one(subset_key: str) -> str:
    task_arn = launch_task(subset_key)
    if not task_arn.startswith("arn:aws:ecs"):
        return task_arn

    while True:
        tasks = ecs.describe_tasks(cluster=CLUSTER, tasks=[task_arn])["tasks"]
        if not tasks or tasks[0]["lastStatus"] in ("STOPPED", "DEPROVISIONING", "DEACTIVATING"):
            if tasks:
                task = tasks[0]
                exit_codes = [c.get("exitCode") for c in task.get("containers", [])]
                status = "OK" if exit_codes == [0] else f"FAILED ({exit_codes})"
                return f"{subset_key}: {status}"
            return f"{subset_key}: task vanished"
        time.sleep(POLL_SECONDS)


def in_flight_keys() -> set[str]:
    """S3_SUBSET_KEY overrides of tasks currently running/pending on the cluster."""
    task_arns = ecs.list_tasks(cluster=CLUSTER, desiredStatus="RUNNING")["taskArns"]
    task_arns += ecs.list_tasks(cluster=CLUSTER, desiredStatus="PENDING")["taskArns"]
    if not task_arns:
        return set()
    keys = set()
    for task in ecs.describe_tasks(cluster=CLUSTER, tasks=task_arns)["tasks"]:
        for override in task.get("overrides", {}).get("containerOverrides", []):
            for env in override.get("environment", []):
                if env["name"] == "S3_SUBSET_KEY":
                    keys.add(env["value"])
    return keys


def main():
    keys = list_subset_keys()
    done = {k for k in keys if already_done(k)}
    in_flight = in_flight_keys()
    pending = [k for k in keys if k not in done and k not in in_flight]
    print(
        f"{len(keys)} subset files, {len(done)} done, {len(in_flight)} in flight, "
        f"launching {len(pending)} tasks (max {MAX_WORKERS} concurrent)",
        flush=True,
    )

    if not pending:
        print("Nothing to do.", flush=True)
        return

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(run_one, k): k for k in pending}
        for future in tqdm(as_completed(futures), total=len(futures)):
            tqdm.write(future.result())


if __name__ == "__main__":
    main()
