import os

import boto3

REGION = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "eu-west-1"))
BUCKET = "map-database"
PREFIX = "combined/"
QUEUE_NAME = "map-database-blast-queue"

s3 = boto3.client("s3", region_name=REGION)
sqs = boto3.client("sqs", region_name=REGION)


def main():
    queue_url = sqs.get_queue_url(QueueName=QUEUE_NAME)["QueueUrl"]

    paginator = s3.get_paginator("list_objects_v2")
    pages = paginator.paginate(Bucket=BUCKET, Prefix=PREFIX)

    keys = []
    for page in pages:
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".fasta"):
                keys.append(key)

    keys.sort()
    print(f"Found {len(keys)} .fasta files in s3://{BUCKET}/{PREFIX}")

    for i, key in enumerate(keys, 1):
        s3_uri = f"s3://{BUCKET}/{key}"
        sqs.send_message(QueueUrl=queue_url, MessageBody=s3_uri)
        print(f"[{i}/{len(keys)}] Queued: {s3_uri}")

    print("Done")


if __name__ == "__main__":
    main()
