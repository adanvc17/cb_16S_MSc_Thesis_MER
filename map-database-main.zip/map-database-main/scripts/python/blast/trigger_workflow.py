import os
import subprocess
import sys
from pathlib import Path

import boto3

BUCKET = "map-database"
PREFIX = "combined/"
INFRA_DIR = Path(__file__).resolve().parent.parent / "infra"

session = boto3.Session(region_name=os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "eu-west-1")))
sfn = session.client("stepfunctions")
s3 = session.client("s3")


def main():
    arn = get_state_machine_arn()

    resp = sfn.start_execution(stateMachineArn=arn)
    execution_arn = resp["executionArn"]
    print(f"\nExecution started: {execution_arn}")
    region = session.region_name
    print(
        f"Console: https://{region}.console.aws.amazon.com/states/home?region={region}#/executions/details/{execution_arn}"
    )


def get_state_machine_arn() -> str:
    result = subprocess.run(
        ["pulumi", "stack", "output", "stateMachineArn"],
        capture_output=True,
        text=True,
        cwd=INFRA_DIR,
        check=False,
    )
    if result.returncode != 0:
        print(f"Failed to get state machine ARN: {result.stderr.strip()}", file=sys.stderr)
        sys.exit(1)

    return result.stdout.strip()


if __name__ == "__main__":
    main()
