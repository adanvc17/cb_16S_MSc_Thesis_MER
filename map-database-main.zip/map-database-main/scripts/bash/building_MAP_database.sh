### BLAST install
## We need install anaconda first in order to create a compatible environment with BLAST
 sudo apt-get update
 sudo apt-get install curl -y
 cd /tmp
 curl -O https://repo.anaconda.com/archive/Anaconda3-2025.12-2-Linux-x86_64.sh
 bash Anaconda3-2025.12-2-Linux-x86_64.sh

## Once Anaconda is installed, we check our version of python
 python3 --version

## We need to update it to 3.10 version, so
 # sudo apt install python3-pip

## and then build our conda environment for blast
 conda create -n blast_env
 conda activate blast_env
 conda config --add channels defaults
 conda config --add channels bioconda
 conda config --add channels conda-forge
 conda config --add channels priority
 conda install blast -y

### Remember: everytime we want to use BLAST, we run
conda activate blast_env

## we are building now a database with the subset of amplicon sequences identified as potentially AR3 and AR4-related
makeblastdb -in MAP_AR3_4_amplicons.fasta -dbtype nucl -out MAP_AR3_4_amplicons_db

### Run Local BLAST
We are running now the 'blastn' command to detect the most similar short-length sequences to AR3 and AR4 clades within the sub-data set retrieved with IMNGS taxonomy query tool

### we are using the option '20' of the -outfmt parameter to visualize the alignment results as comma-separated values with header lines. As well as tell the algorithm to retrieve the
### following columns in the output: qseqid sseqid pident length evalue bitscore qcovs qcovhsp, so that we can see not only the identity percentage but the length of reads, as well as the
### coverage percentage per alignment (whole and fragmented)

 blastn -query AR3_AR4_PL.fasta \
  -db MAP_AR3_4_amplicons_db \
  -out MAP_blast_raw.csv \
  -outfmt "20 qseqid sseqid pident length evalue bitscore qcovs qcovhsp"
