#!/usr/bin/env bash
set -euo pipefail

CLUSTER="map-database"
TASK_DEF="map-database:2"
SUBNETS="subnet-0ae393abd1722fb12,subnet-005ac7f5fc836b38c,subnet-05481e5c9bcce4835"
CHUNKS_BUCKET="map-database"
MAX_RUNNING="${1:-15}"

cd "$(dirname "$0")/chunks" 2>/dev/null || { echo "chunks/ directory not found"; exit 1; }
chunks=(chunk_*)

submitted=0
echo "Submitting all ${#chunks[@]} chunks (max $MAX_RUNNING concurrent)..."
echo

for chunk in "${chunks[@]}"; do
  [ -f "$chunk" ] || continue

  while : ; do
    # wait until we're below the concurrency ceiling
    while : ; do
      running=$(aws ecs list-tasks --cluster "$CLUSTER" --family map-database \
        --desired-status RUNNING --query 'length(taskArns)' --output text 2>/dev/null || echo 0)
      [ "$running" -lt "$MAX_RUNNING" ] 2>/dev/null && break
      echo "  $chunk: waiting ($running running, limit $MAX_RUNNING)"
      sleep 10
    done

    result=$(aws ecs run-task \
      --cluster "$CLUSTER" \
      --launch-type FARGATE \
      --task-definition "$TASK_DEF" \
      --network-configuration "awsvpcConfiguration={subnets=[$SUBNETS],assignPublicIp=ENABLED}" \
      --overrides '{"containerOverrides":[{"name":"app","command":["batch_fasta_download.py","s3://'"$CHUNKS_BUCKET/chunks/$chunk"'"]}]}' \
      --query 'tasks[0].taskArn' --output text 2>&1)

    if [ -n "$result" ] && [ "$result" != "None" ] && ! echo "$result" | grep -qi "error\|throttl\|limit\|unable\|AccessDenied"; then
      echo "OK: $chunk -> ${result##*/}"
      submitted=$((submitted + 1))
      break
    fi

    # failed — back off and retry
    echo "RETRY: $chunk ($result)"
    sleep 5
  done

done

echo
echo "Done. Submitted: $submitted / ${#chunks[@]}"
