#!/usr/bin/env bash
set -euo pipefail

export AWS_PROFILE="marine-biology"
FUNCTION_NAME="${1:-map-database}"
REGION="${AWS_REGION:-eu-west-1}"
ACCOUNT_ID="315661564391"
REPO="${FUNCTION_NAME}"
TAG="latest"

IMAGE="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${REPO}:${TAG}"

aws ecr describe-repositories --repository-names "${REPO}" --region "${REGION}" >/dev/null 2>&1 ||
	aws ecr create-repository --repository-name "${REPO}" --region "${REGION}"

aws ecr get-login-password --region "${REGION}" \
	| docker login --username AWS --password-stdin "${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com"

docker build -t "${REPO}:${TAG}" .
docker tag "${REPO}:${TAG}" "${IMAGE}"
docker push "${IMAGE}"

if aws lambda get-function --function-name "${FUNCTION_NAME}" --region "${REGION}" >/dev/null 2>&1; then
	aws lambda update-function-code \
		--function-name "${FUNCTION_NAME}" \
		--image-uri "${IMAGE}" \
		--region "${REGION}"
else
	aws lambda create-function \
		--function-name "${FUNCTION_NAME}" \
		--package-type Image \
		--code ImageUri="${IMAGE}" \
		--role "arn:aws:iam::${ACCOUNT_ID}:role/${FUNCTION_NAME}-role" \
		--region "${REGION}" \
		--timeout 900 \
		--memory-size 1024
fi
