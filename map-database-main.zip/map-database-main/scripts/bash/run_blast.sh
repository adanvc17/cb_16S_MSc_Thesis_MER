#!/usr/bin/env bash
set -euo pipefail

source /opt/anaconda3/etc/profile.d/conda.sh
conda activate blast_env

input_ref="s3://${S3_INPUT_BUCKET}/${S3_INPUT_KEY}"
bucket="${S3_OUTPUT_BUCKET:-map-database}"

local_path="/tmp/$(basename "$input_ref")"
echo "Downloading $input_ref -> $local_path"
aws s3 cp "$input_ref" "$local_path" --no-progress

stem="$(basename "$local_path" .fasta)"
stem="$(basename "$stem" .fa)"
stem="$(basename "$stem" .fna)"
stem="$(basename "$stem" .faa)"

echo "Creating BLAST database from $local_path"
makeblastdb -in "$local_path" -dbtype nucl -out "/tmp/${stem}_db"

echo "Running blastn"
blastn -query AR3_AR4_PL.fasta \
    -db "/tmp/${stem}_db" \
    -out "${stem}.csv" \
    -outfmt "20 qseqid sseqid pident length evalue bitscore qcovs qcovhsp"

echo "Uploading ${stem}.csv to s3://${bucket}/blast/${stem}.csv"
aws s3 cp "${stem}.csv" "s3://${bucket}/blast/${stem}.csv" --no-progress

echo "Done"
