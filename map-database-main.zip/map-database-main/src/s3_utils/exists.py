import boto3
from botocore.exceptions import ClientError

s3 = boto3.client("s3")


def object_exists(bucket: str, key: str, client=None) -> bool:
    """Return True if the object exists in S3; 404/403 (not there/inaccessible) count as missing."""
    client = client or s3
    try:
        client.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] in ("404", "403"):
            return False
        raise