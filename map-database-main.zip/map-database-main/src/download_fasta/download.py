import gzip
import os
import shutil
import subprocess
import urllib.request

import boto3

result: dict[str, set[str]] = {}

with open("taxon_all_amplicon_BioSamples_Runs_MAP_AR3_4.txt") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        id_, run = line.split(",")
        result.setdefault(id_, set()).add(run)

s3 = boto3.client("s3")
bucket = os.environ.get("S3_BUCKET", "map-database")


def _run(cmd: list[str], **kwargs):
    res = subprocess.run(cmd, stderr=subprocess.PIPE, **kwargs)
    if res.returncode != 0:
        msg = f"Command {' '.join(cmd)} failed (exit {res.returncode}):\n{res.stderr.decode()}"
        raise RuntimeError(msg)
    return res


def _download_url(url: str, dest: str):
    _run(["curl", "-L", "--fail", "--retry", "3", "--connect-timeout", "30", "-o", dest, url])


def _download_ena_fastq(run: str):
    api = f"https://www.ebi.ac.uk/ena/portal/api/filereport?accession={run}&result=read_run&fields=fastq_ftp&format=tsv"
    with urllib.request.urlopen(api, timeout=15) as resp:
        for line in resp.read().decode().strip().splitlines():
            if line.startswith("study_accession"):
                continue

            urls = line.strip().split("\t")[-1]
            if not urls or urls == "fastq_ftp":
                continue

            return [f"https://{u}" if not u.startswith("https://") else u for u in urls.split(";")]
    raise RuntimeError(f"{run} not found on ENA")


def _download_ena(run: str):
    urls = _download_ena_fastq(run)
    downloaded = []
    for url in urls:
        fname = url.rstrip(".gz").rsplit("/", 1)[-1]
        print(f"ENA: downloading {url} ...")
        gzpath = f"/tmp/{fname}.gz"
        _download_url(url, gzpath)
        print("ENA: decompressing ...")
        with gzip.open(gzpath, "rb") as gz, open(f"/tmp/{fname}", "wb") as f:
            shutil.copyfileobj(gz, f)
        os.remove(gzpath)
        downloaded.append(fname)
        print(f"ENA: downloaded {fname}")
    if not downloaded:
        raise RuntimeError(f"ENA download failed for {run}")
    return downloaded


def _download_ncbi_sra(run: str):
    url = f"https://sra-pub-run-odp.s3.amazonaws.com/sra/{run}/{run}"
    sra_path = f"/tmp/{run}.sra"
    print(f"NCBI S3: downloading {url} ...")
    _download_url(url, sra_path)
    size = os.path.getsize(sra_path)
    print(f"NCBI S3: downloaded {run}.sra ({size} bytes), extracting FASTQ ...")
    _run(["fasterq-dump", "--force", "--mem", "256", "--split-files", sra_path])
    os.remove(sra_path)
    for fname in os.listdir("/tmp"):
        if fname.startswith(run) and fname.endswith(".fastq"):
            print(f"NCBI S3: extracted {fname}")


def download_fasta(id_: str):
    os.chdir("/tmp")

    runs = result.get(id_)
    if not runs:
        return {"statusCode": 404, "body": f"ID {id_} not found"}

    for run in runs:
        try:
            _download_ena(run)
        except RuntimeError as e:
            print(f"ENA failed for {run}: {e}")
            try:
                _download_ncbi_sra(run)
            except RuntimeError as e:
                raise RuntimeError(f"All download methods failed for {run}: {e}")

        base = run
        single = f"{base}.fastq"
        paired1 = f"{base}_1.fastq"
        paired2 = f"{base}_2.fastq"

        if os.path.exists(single):
            fasta = f"{base}.fasta"
            _run(["seqtk", "seq", "-A", single], stdout=open(fasta, "w"))
        elif os.path.exists(paired1) and os.path.exists(paired2):
            merged = f"{base}_merged.fastq"
            _run(
                ["vsearch", "--fastq_mergepairs", paired1, "--reverse", paired2, "--fastqout", merged],
            )
            fasta = f"{base}_merged.fasta"
            _run(["seqtk", "seq", "-A", merged], stdout=open(fasta, "w"))
        else:
            raise FileNotFoundError(f"Neither {single} nor {paired1}/{paired2} found after download")

        s3.upload_file(fasta, bucket, fasta)

        for f in os.listdir("/tmp"):
            if f.startswith(base):
                os.remove(f"/tmp/{f}")
