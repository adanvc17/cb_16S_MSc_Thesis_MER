import csv
from collections.abc import Iterator
from pathlib import Path


def main(
    file_fasta: Path,
    file_subset: Path,
) -> list[tuple[str, str]]:
    """Return (header, seq) tuples for the FASTA records kept in the subset list."""
    wanted_ids = read_subset_ids(file_subset)
    with file_fasta.open() as f:
        return extract_sequences(f, wanted_ids)


def read_subset_ids(file_subset: Path) -> set[str]:
    """Return every accession id found in the second CSV column of a clean file."""
    with file_subset.open(newline="") as f:
        reader = csv.reader(f)
        return {row[1].strip() for row in reader if len(row) > 1 and row[1].strip()}


def extract_sequences(
    lines: Iterator[str],
    wanted_ids: set[str],
) -> list[tuple[str, str]]:
    """Return every (header, seq) FASTA record whose accession is in wanted_ids."""
    return [(header, seq) for header, seq in fasta_records(lines) if extract_accession(header) in wanted_ids]


def fasta_records(lines: Iterator[str]) -> Iterator[tuple[str, str]]:
    """Yield (header, sequence) pairs from an iterator of FASTA lines."""
    header = None
    seq: list[str] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if header is not None:
                yield header, "".join(seq)
            header = line
            seq = []
        else:
            seq.append(line)

    if header is not None:
        yield header, "".join(seq)


def extract_accession(header: str) -> str:
    """Return the accession id from a FASTA header, e.g. '>M00001 desc' -> 'M00001'."""
    return header.lstrip(">").split(maxsplit=1)[0]


# if __name__ == "__main__":
#     import glob
#     import os

#     import boto3

#     s3 = boto3.client("s3")

#     for path in glob.glob("./retained_blasts/*.csv"):
#         filename = path.split("/")[-1]  # "batch-120_filtered_clean.csv"
#         batch_id = filename.split("_")[0].split("-")[1]  # "120"

#         key = f"combined/batch-{batch_id}.fasta"
#         outpath = f"/tmp/fasta/batch-{batch_id}.fasta"

#         if not os.path.exists(outpath):
#             print(f"downloading {outpath}")
#             s3.download_file("map-database", key, "/tmp/fasta/batch-{batch_id}.fasta")
