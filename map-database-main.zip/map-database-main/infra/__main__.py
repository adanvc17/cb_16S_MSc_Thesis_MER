import json

import pulumi
import pulumi_aws as aws
import pulumi_awsx as awsx

config = pulumi.Config()

# --- Required config (set via `pulumi config set <key> <value>`) ---
input_bucket_name = config.require("inputBucket")
output_bucket_name = config.require("outputBucket")

# --- Optional config ---
input_prefix = config.get("inputPrefix") or ""
max_concurrency = config.get_int("maxConcurrency") or 10
# Path to the Docker build context directory (repo root).
docker_context = config.get("dockerContext") or ".."

# -----------------------------------------------------------------------
# Networking - uses the account's default VPC/subnets for simplicity.
# Default VPC subnets are public, so tasks get a public IP for ECR/S3
# egress. Swap for private subnets + NAT (or S3/ECR VPC endpoints) in
# production.
# -----------------------------------------------------------------------
default_vpc = aws.ec2.get_vpc(default=True)
default_subnets = aws.ec2.get_subnets(
    filters=[aws.ec2.GetSubnetsFilterArgs(name="vpc-id", values=[default_vpc.id])]
)

task_security_group = aws.ec2.SecurityGroup(
    "file-processor-sg",
    vpc_id=default_vpc.id,
    egress=[
        aws.ec2.SecurityGroupEgressArgs(
            protocol="-1", from_port=0, to_port=0, cidr_blocks=["0.0.0.0/0"],
        )
    ],
)

# -----------------------------------------------------------------------
# Container image - builds from your existing Dockerfile and pushes to a
# new ECR repo. Requires a local Docker daemon at `pulumi up` time.
# -----------------------------------------------------------------------
repo = awsx.ecr.Repository("file-processor-repo", force_delete=True)

image = awsx.ecr.Image(
    "file-processor-image",
    repository_url=repo.url,
    context=docker_context,
    dockerfile="../dockerfiles/fargate-blast/Dockerfile",
)

# -----------------------------------------------------------------------
# ECS cluster + logging
# -----------------------------------------------------------------------
cluster = aws.ecs.Cluster("file-processor-cluster")

log_group = aws.cloudwatch.LogGroup("file-processor-logs", retention_in_days=7)

# -----------------------------------------------------------------------
# IAM: task execution role (pulls image, writes logs)
# -----------------------------------------------------------------------
execution_role = aws.iam.Role(
    "file-processor-exec-role",
    assume_role_policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "ecs-tasks.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ],
        }
    ),
)

aws.iam.RolePolicyAttachment(
    "file-processor-exec-role-policy",
    role=execution_role.name,
    policy_arn="arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy",
)

# -----------------------------------------------------------------------
# IAM: task role (your application's own S3 permissions - least privilege)
# -----------------------------------------------------------------------
task_role = aws.iam.Role(
    "file-processor-task-role",
    assume_role_policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "ecs-tasks.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ],
        }
    ),
)

aws.iam.RolePolicy(
    "file-processor-task-role-policy",
    role=task_role.id,
    policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": ["s3:GetObject"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}/*",
                },
                {
                    "Effect": "Allow",
                    "Action": ["s3:PutObject"],
                    "Resource": f"arn:aws:s3:::{output_bucket_name}/*",
                },
            ],
        }
    ),
)

# -----------------------------------------------------------------------
# ECS task definition - your worker stays a one-shot script:
# read S3_INPUT_KEY, write results/{key}.csv to S3_OUTPUT_BUCKET, exit.
# -----------------------------------------------------------------------
container_definitions = pulumi.Output.all(image.image_uri, log_group.name).apply(
    lambda args: json.dumps(
        [
            {
                "name": "processor",
                "image": args[0],
                "essential": True,
                "logConfiguration": {
                    "logDriver": "awslogs",
                    "options": {
                        "awslogs-group": args[1],
                        "awslogs-region": aws.config.region,
                        "awslogs-stream-prefix": "processor",
                    },
                },
            }
        ]
    )
)

task_definition = aws.ecs.TaskDefinition(
    "file-processor-task",
    family="file-processor",
    cpu="512",
    memory="1024",
    network_mode="awsvpc",
    requires_compatibilities=["FARGATE"],
    execution_role_arn=execution_role.arn,
    task_role_arn=task_role.arn,
    container_definitions=container_definitions,
)

# -----------------------------------------------------------------------
# IAM: Step Functions execution role
# -----------------------------------------------------------------------
state_machine_role = aws.iam.Role(
    "file-processor-sfn-role",
    assume_role_policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "states.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ],
        }
    ),
)


def build_sfn_policy(args):
    task_def_arn, exec_role_arn, task_role_arn = args
    return json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": ["s3:ListBucket"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}",
                },
                {"Effect": "Allow", "Action": ["ecs:RunTask"], "Resource": task_def_arn},
                {
                    "Effect": "Allow",
                    "Action": ["ecs:StopTask", "ecs:DescribeTasks"],
                    "Resource": "*",
                },
                {
                    "Effect": "Allow",
                    "Action": ["iam:PassRole"],
                    "Resource": [exec_role_arn, task_role_arn],
                },
                {
                    # Required because ecs:runTask.sync uses an EventBridge
                    # rule to wait for the ECS task to finish.
                    "Effect": "Allow",
                    "Action": ["events:PutTargets", "events:PutRule", "events:DescribeRule"],
                    "Resource": "arn:aws:events:*:*:rule/StepFunctionsGetEventsForECSTaskRule",
                },
            ],
        }
    )


aws.iam.RolePolicy(
    "file-processor-sfn-role-policy",
    role=state_machine_role.id,
    policy=pulumi.Output.all(
        task_definition.arn, execution_role.arn, task_role.arn
    ).apply(build_sfn_policy),
)

# -----------------------------------------------------------------------
# State machine: list objects in the input bucket, then run one ECS task
# per key (bounded concurrency), writing failures into $.error instead of
# failing the whole execution.
#
# Note: S3 ListObjectsV2 returns at most 1000 keys per call and this
# definition does not paginate. Fine up to ~1000 files; add a pagination
# loop (NextContinuationToken) if your input bucket can exceed that.
# -----------------------------------------------------------------------
def build_definition(args):
    cluster_arn, task_def_arn, subnet_ids, sg_id = args
    return json.dumps(
        {
            "Comment": "Process each file in the input bucket via an ECS Fargate task, one CSV per file.",
            "StartAt": "ListFiles",
            "States": {
                "ListFiles": {
                    "Type": "Task",
                    "Resource": "arn:aws:states:::aws-sdk:s3:listObjectsV2",
                    "Parameters": {
                        "Bucket": input_bucket_name,
                        "Prefix": input_prefix,
                    },
                    "ResultSelector": {
                        "keys.$": "$.Contents[*].Key",
                    },
                    "Next": "ProcessFiles",
                },
                "ProcessFiles": {
                    "Type": "Map",
                    "ItemsPath": "$.keys",
                    "MaxConcurrency": max_concurrency,
                    "ItemProcessor": {
                        "ProcessorConfig": {"Mode": "INLINE"},
                        "StartAt": "RunProcessingTask",
                        "States": {
                            "RunProcessingTask": {
                                "Type": "Task",
                                "Resource": "arn:aws:states:::ecs:runTask.sync",
                                "Parameters": {
                                    "Cluster": cluster_arn,
                                    "TaskDefinition": task_def_arn,
                                    "LaunchType": "FARGATE",
                                    "NetworkConfiguration": {
                                        "AwsvpcConfiguration": {
                                            "Subnets": subnet_ids,
                                            "SecurityGroups": [sg_id],
                                            "AssignPublicIp": "ENABLED",
                                        }
                                    },
                                    "Overrides": {
                                        "ContainerOverrides": [
                                            {
                                                "Name": "processor",
                                                "Environment": [
                                                    {
                                                        "Name": "S3_INPUT_BUCKET",
                                                        "Value": input_bucket_name,
                                                    },
                                                    {"Name": "S3_INPUT_KEY", "Value.$": "$"},
                                                    {
                                                        "Name": "S3_OUTPUT_BUCKET",
                                                        "Value": output_bucket_name,
                                                    },
                                                ],
                                            }
                                        ]
                                    },
                                },
                                "ResultSelector": {
                                    "output_bucket": output_bucket_name,
                                    "output_key.$": "States.Format('results/{}.csv', $.Tasks[0].Overrides.ContainerOverrides[0].Environment[1].Value)",
                                },
                                "Retry": [
                                    {
                                        "ErrorEquals": ["States.ALL"],
                                        "IntervalSeconds": 10,
                                        "MaxAttempts": 2,
                                        "BackoffRate": 2,
                                    }
                                ],
                                "Catch": [
                                    {
                                        "ErrorEquals": ["States.ALL"],
                                        "ResultPath": "$.error",
                                        "Next": "RecordFailure",
                                    }
                                ],
                                "End": True,
                            },
                            "RecordFailure": {"Type": "Pass", "End": True},
                        },
                    },
                    "End": True,
                },
            },
        }
    )


definition = pulumi.Output.all(
    cluster.arn, task_definition.arn, default_subnets.ids, task_security_group.id
).apply(build_definition)

state_machine = aws.sfn.StateMachine(
    "file-processor-workflow",
    role_arn=state_machine_role.arn,
    definition=definition,
)

# -----------------------------------------------------------------------
# Subset-fasta Lambda - Docker image built from the same build context.
# -----------------------------------------------------------------------
subset_repo = awsx.ecr.Repository("subset-fasta-repo", force_delete=True)

subset_image = awsx.ecr.Image(
    "subset-fasta-image",
    repository_url=subset_repo.url,
    context=docker_context,
    dockerfile="../dockerfiles/subset_lambda/Dockerfile",
)

subset_lambda_role = aws.iam.Role(
    "subset-fasta-lambda-role",
    assume_role_policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "lambda.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ],
        }
    ),
)

aws.iam.RolePolicy(
    "subset-fasta-lambda-role-policy",
    role=subset_lambda_role.id,
    policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    # Needed so head_object on a missing subset-outputs key
                    # returns 404 instead of 403.
                    "Effect": "Allow",
                    "Action": ["s3:ListBucket"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}",
                },
                {
                    # Reads both the FASTA files and the subset lists.
                    "Effect": "Allow",
                    "Action": ["s3:GetObject"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}/*",
                },
                {
                    # Writes the filtered records to subset-outputs/.
                    "Effect": "Allow",
                    "Action": [
                        "s3:PutObject",
                        "s3:AbortMultipartUpload",
                        "s3:ListMultipartUploadParts",
                    ],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}/subset-outputs/*",
                },
                {
                    "Effect": "Allow",
                    "Action": [
                        "logs:CreateLogGroup",
                        "logs:CreateLogStream",
                        "logs:PutLogEvents",
                    ],
                    "Resource": "*",
                },
            ],
        }
    ),
)

subset_function = aws.lambda_.Function(
    "subset-fasta",
    image_uri=subset_image.image_uri,
    package_type="Image",
    role=subset_lambda_role.arn,
    timeout=900,
    memory_size=3008,
    ephemeral_storage={
        "size": 10240,
    },
)

# -----------------------------------------------------------------------
# Subset-fasta Fargate task - same job as the Lambda, but run as a one-shot
# ECS task per subset file (no 15-min / response-size limits, no concurrency
# cap). The subset key is passed per task via a container override
# (S3_SUBSET_KEY). Launch tasks with scripts/python/subset/trigger_subset_fasta_tasks.py.
# -----------------------------------------------------------------------
subset_fargate_repo = awsx.ecr.Repository("subset-fasta-fargate-repo", force_delete=True)

subset_fargate_image = awsx.ecr.Image(
    "subset-fasta-fargate-image",
    repository_url=subset_fargate_repo.url,
    context=docker_context,
    dockerfile="../dockerfiles/subset-fargate/Dockerfile",
)

subset_fargate_log_group = aws.cloudwatch.LogGroup(
    "subset-fasta-fargate-logs", retention_in_days=7
)

subset_fargate_exec_role = aws.iam.Role(
    "subset-fasta-fargate-exec-role",
    assume_role_policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "ecs-tasks.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ],
        }
    ),
)

aws.iam.RolePolicyAttachment(
    "subset-fasta-fargate-exec-role-policy",
    role=subset_fargate_exec_role.name,
    policy_arn="arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy",
)

subset_fargate_task_role = aws.iam.Role(
    "subset-fasta-fargate-task-role",
    assume_role_policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "ecs-tasks.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }
            ],
        }
    ),
)

aws.iam.RolePolicy(
    "subset-fasta-fargate-task-role-policy",
    role=subset_fargate_task_role.id,
    policy=json.dumps(
        {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": ["s3:ListBucket"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}",
                },
                {
                    "Effect": "Allow",
                    "Action": ["s3:GetObject"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}/*",
                },
                {
                    "Effect": "Allow",
                    "Action": ["s3:PutObject"],
                    "Resource": f"arn:aws:s3:::{input_bucket_name}/subset-outputs/*",
                },
            ],
        }
    ),
)

subset_fargate_container_definitions = pulumi.Output.all(
    subset_fargate_image.image_uri, subset_fargate_log_group.name
).apply(
    lambda args: json.dumps(
        [
            {
                "name": "subset-fasta",
                "image": args[0],
                "essential": True,
                "environment": [
                    {"Name": "S3_BUCKET", "Value": input_bucket_name},
                    {"Name": "FASTA_PREFIX", "Value": "combined/"},
                    {"Name": "OUTPUT_PREFIX", "Value": "subset-outputs/"},
                ],
                "logConfiguration": {
                    "logDriver": "awslogs",
                    "options": {
                        "awslogs-group": args[1],
                        "awslogs-region": aws.config.region,
                        "awslogs-stream-prefix": "subset-fasta",
                    },
                },
            }
        ]
    )
)

subset_fargate_task_definition = aws.ecs.TaskDefinition(
    "subset-fasta-fargate-task",
    family="subset-fasta-fargate",
    cpu="1024",
    memory="2048",
    network_mode="awsvpc",
    requires_compatibilities=["FARGATE"],
    execution_role_arn=subset_fargate_exec_role.arn,
    task_role_arn=subset_fargate_task_role.arn,
    container_definitions=subset_fargate_container_definitions,
)

pulumi.export("stateMachineArn", state_machine.arn)
pulumi.export("clusterName", cluster.name)
pulumi.export("ecrRepoUrl", repo.url)
pulumi.export("subsetFunctionName", subset_function.name)
pulumi.export("subsetFargateTaskDefinitionArn", subset_fargate_task_definition.arn)