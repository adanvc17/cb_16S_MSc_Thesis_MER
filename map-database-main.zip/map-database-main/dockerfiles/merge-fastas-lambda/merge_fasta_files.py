"""
AWS Lambda handler: streams a list of S3 FASTA files into a single
output object, using real multipart `upload_part` calls (not copy),
so it works regardless of how small individual source files are.

Event shape:
{
    "keys": ["fasta-files/a.fasta", "fasta-files/b.fasta", ...],
    "id": "batch-00001",
}

Notes:
- No /tmp usage: everything is streamed through a small in-memory buffer.
- MIN_PART_SIZE controls how much is buffered before each part is flushed;
  8 MB gives headroom above S3's 5 MB minimum for non-final parts.
- Deploy with generous memory (Lambda network throughput scales with
  memory) and timeout set to the max (900s), then size batches from the
  orchestrator so each invocation comfortably finishes well within that.
"""

import boto3
from botocore.config import Config

s3 = boto3.client("s3", config=Config(max_pool_connections=50))

MIN_PART_SIZE = 8 * 1024 * 1024  # 8 MB
READ_CHUNK = 1024 * 1024  # 1 MB read chunks from each source object
SOURCE_BUCKET = "map-database"
DEST_BUCKET = "map-database"


def lambda_handler(event, context):
    keys = event["keys"]
    batch_id = event["id"]

    dest_key = f"combined/batch-{batch_id}.fasta"

    if not keys:
        raise ValueError("keys list is empty")

    mpu = s3.create_multipart_upload(Bucket=DEST_BUCKET, Key=dest_key)
    upload_id = mpu["UploadId"]

    parts = []
    part_number = 1
    buffer = bytearray()
    bytes_written = 0
    files_processed = 0

    def flush(final=False):
        nonlocal buffer, part_number, bytes_written
        if not buffer:
            return

        if not final and len(buffer) < MIN_PART_SIZE:
            return

        resp = s3.upload_part(
            Bucket=DEST_BUCKET,
            Key=dest_key,
            PartNumber=part_number,
            UploadId=upload_id,
            Body=bytes(buffer),
        )
        parts.append({"PartNumber": part_number, "ETag": resp["ETag"]})
        bytes_written += len(buffer)
        part_number += 1
        buffer = bytearray()

    try:
        for key in keys:
            obj = s3.get_object(Bucket=SOURCE_BUCKET, Key=key)
            body = obj["Body"]
            while True:
                chunk = body.read(READ_CHUNK)
                if not chunk:
                    break
                buffer.extend(chunk)
                if len(buffer) >= MIN_PART_SIZE:
                    flush()
            files_processed += 1

        # Final part is allowed to be under 5 MB.
        flush(final=True)

        if not parts:
            s3.abort_multipart_upload(Bucket=DEST_BUCKET, Key=dest_key, UploadId=upload_id)
            raise ValueError("No data written -- source files may be empty")

        s3.complete_multipart_upload(
            Bucket=DEST_BUCKET,
            Key=dest_key,
            UploadId=upload_id,
            MultipartUpload={"Parts": parts},
        )

    except Exception:
        s3.abort_multipart_upload(Bucket=DEST_BUCKET, Key=dest_key, UploadId=upload_id)
        raise

    return {
        "id": batch_id,
        "files_processed": files_processed,
        "bytes_written": bytes_written,
    }
