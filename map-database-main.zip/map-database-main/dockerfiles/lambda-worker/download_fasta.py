from src.download_fasta.download import download_fasta


def lambda_handler(event, context):
    id_ = event["id"]
    try:
        download_fasta(id_)
    except Exception as e:
        return {"statusCode": 500, "body": f"failed: {e}"}

    return {"statusCode": 200, "body": f"Done processing {id_}"}
