"""
AWS Lambda handler: keep only the records from `fasta` whose accession id is
listed in `subset`, streaming both objects from S3 so memory stays flat, and
write the filtered records to S3 as FASTA.

Event shape:
{
    "fasta": "s3://map-database/combined/batch-000.fasta",
    "subset": "s3://map-database/retained_blasts/batch-000_filtered_clean.csv",
    "output": "s3://map-database/subset-outputs/batch-000.subset.fasta",  # optional
}

If `output` is omitted it defaults to
s3://<fasta-bucket>/subset-outputs/<batch>.subset.fasta, where <batch> is
taken from the subset filename (strip "_filtered_clean.csv").

The subset file is read fully (it is small); the FASTA file is streamed through
a 1 MB chunk buffer. Filtered records are written to S3 as a multipart upload
(5 MB parts) so memory stays flat regardless of output size. If the output
object already exists, the run is skipped and `skipped` is returned as True.

Returns:
{
    "count": n,
    "num_wanted_ids": len(wanted_ids),
    "output": "s3://<bucket>/subset-outputs/<batch>.subset.fasta",
    "skipped": False,
}
"""

import csv
import os
from pathlib import Path

import boto3
from boto3.s3.transfer import TransferConfig

from src.s3_utils.exists import object_exists
from src.subset.fasta import extract_accession, fasta_records

s3 = boto3.client("s3")
DOWNLOAD_CONFIG = TransferConfig(
    multipart_threshold=8 * 1024 * 1024,
    multipart_chunksize=16 * 1024 * 1024,
    max_concurrency=16,
    use_threads=True,
)

READ_CHUNK = 1024 * 1024  # 1 MB
UPLOAD_PART = 5 * 1024 * 1024  # 5 MB


def lambda_handler(event, context):
    fasta_bucket, fasta_key = split_bucket(event["fasta"])
    subset_bucket, subset_key = split_bucket(event["subset"])

    if event.get("output"):
        output_bucket, output_key = split_bucket(event["output"])
    else:
        output_bucket, output_key = default_output_path(fasta_bucket, subset_key)

    if object_exists(output_bucket, output_key):
        return {
            "count": None,
            "num_wanted_ids": None,
            "output": f"s3://{output_bucket}/{output_key}",
            "skipped": True,
        }

    wanted_ids = read_present_ids(subset_bucket, subset_key)

    local_fasta = Path(f"/tmp/{output_key}")
    local_fasta.parent.mkdir(exist_ok=True)

    s3.download_file(fasta_bucket, fasta_key, local_fasta, Config=DOWNLOAD_CONFIG)

    with open(local_fasta, "r") as f:
        count = upload_filtered_fasta(output_bucket, output_key, fasta_records(f), wanted_ids)

    local_fasta.unlink()

    return {
        "count": count,
        "num_wanted_ids": len(wanted_ids),
        "output": f"s3://{output_bucket}/{output_key}",
        "skipped": False,
    }


def default_output_path(fasta_bucket: str, subset_key: str) -> tuple[str, str]:
    """s3://<bucket>/subset-outputs/<batch>.subset.fasta from the subset key."""
    batch = os.path.basename(subset_key).removesuffix("_filtered_clean.csv")
    return fasta_bucket, f"subset-outputs/{batch}.subset.fasta"


def upload_filtered_fasta(bucket: str, key: str, records, wanted_ids: set[str]) -> int:
    """Write filtered FASTA records to S3 as a multipart upload; return the count."""
    created = s3.create_multipart_upload(Bucket=bucket, Key=key)
    upload_id = created["UploadId"]

    parts = []
    part_number = 1
    buffer = bytearray()
    count = 0
    try:
        for header, seq in records:
            if extract_accession(header) not in wanted_ids:
                continue
            count += 1
            buffer.extend(f"{header}\n{seq}\n".encode())

            if len(buffer) >= UPLOAD_PART:
                _upload_part(bucket, key, upload_id, part_number, bytes(buffer), parts)
                part_number += 1
                buffer = bytearray()

        _upload_part(bucket, key, upload_id, part_number, bytes(buffer), parts)

        s3.complete_multipart_upload(
            Bucket=bucket,
            Key=key,
            UploadId=upload_id,
            MultipartUpload={"Parts": parts},
        )
    except Exception:
        s3.abort_multipart_upload(Bucket=bucket, Key=key, UploadId=upload_id)
        raise

    return count


def _upload_part(bucket: str, key: str, upload_id: str, part_number: int, body: bytes, parts: list) -> None:
    response = s3.upload_part(
        Bucket=bucket,
        Key=key,
        UploadId=upload_id,
        PartNumber=part_number,
        Body=body,
    )
    parts.append({"PartNumber": part_number, "ETag": response["ETag"]})


def split_bucket(path: str) -> tuple[str, str]:
    _, location = path.split("://", 1)
    bucket, _, key = location.partition("/")
    if not bucket or not key:
        raise ValueError(f"expected s3://<bucket>/<key>, got {path!r}")
    return bucket, key


def read_present_ids(bucket: str, key: str) -> set[str]:
    """Stream the subset CSV and return the ids from its second column."""
    body = s3.get_object(Bucket=bucket, Key=key)["Body"]
    return {row[1].strip() for row in csv.reader(iter_text_lines(body)) if len(row) > 1 and row[1].strip()}


def iter_text_lines(body, chunk_size: int = READ_CHUNK) -> iter[str]:
    """Yield decoded text lines from an S3 streaming body."""
    buffer = ""
    while True:
        chunk = body.read(chunk_size)
        if not chunk:
            break

        buffer += chunk.decode("utf-8")

        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            yield line.rstrip("\r")

    if buffer:
        yield buffer.rstrip("\r")
