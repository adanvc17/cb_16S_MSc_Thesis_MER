# map-database

Tooling for downloading and processing FASTA data to build the MAP (AR3/AR4) amplicon database.

## What it does

1. **Download** — fetches FASTQ reads for a list of taxon IDs from ENA (or NCBI SRA as fallback), converts them to FASTA with `seqtk`/`vsearch`, and uploads them to S3.
2. **Process** — subsets FASTA files by accession lists, merges batches, and prepares sequences for BLAST against the MAP AR3/AR4 database.
3. **Orchestrate** — runs the pipeline on AWS via Step Functions and Lambda/Fargate containers (Pulumi infra in `infra/`).

## Layout

| Path | Purpose |
| --- | --- |
| `src/` | Core Python packages: `download_fasta`, `subset`, `s3_utils` |
| `scripts/python/` | Pipeline stage scripts: `download/` (Fargate worker + Lambda invoker + chunk submitter), `merge/` (merge Lambda invoker), `subset/` (Fargate worker + Lambda invoker + task trigger + validation), `blast/` (SQS submission + Step Functions trigger) |
| `scripts/bash/` | BLAST install + database build scripts |
| `lambdas/` + `dockerfiles/` | Container images for Lambda and Fargate workers |
| `infra/` | Pulumi infrastructure (see its own README) |
| `resources/` | Taxon/amplicon id lists used as input |

## Setup

Requires Python >= 3.14 and `uv`.

```sh
uv sync
```

## Usage

```sh
uv run python scripts/python/download/batch_fasta_download.py <ids_file_or_s3_uri>  # download+convert+upload FASTA
uv run python scripts/python/blast/trigger_workflow.py                              # start the Step Functions workflow
```

Note: `src/download_fasta` downloads FASTQ into `/tmp` and expects `curl`, `seqtk`, and `vsearch` on the PATH; it is designed to run inside the Lambda/Fargate containers in `dockerfiles/`.