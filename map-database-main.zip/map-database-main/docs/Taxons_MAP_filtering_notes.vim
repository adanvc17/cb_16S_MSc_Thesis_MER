#HOW TO FILTER MAP taxons using environmental info
#There's a file at MAP Project called 'samples.env.info.tsv', from which we
#are taking all samples labelled as 'marine' 'aquatic' 'soil' 'sediment'
#
grep -e "marine sediment" -e "aquatic sediment" -e "rhizosphere" -e "lake sediment" -e "mangrove" -e "seagrass" -e "salt marsh" samples.env.info.tsv > samples.env.info.filt.tsv

#And then take all those explicitly reported as Amplicon
grep -e 'AMPLICON' samples.env.info.filt.tsv > samples.env.info.amplicon.tsv

#Then we extract the ids present at a given MAP taxon of interest
cut -f1 taxon_90_1596_samples.tsv > taxon_90_1596_samples_ids_raw.txt

#So that we can search those samples that contain our environmental info
grep -Ff taxon_90_1596_samples_ids_raw.txt samples.env.info.amplicon.tsv > taxon_90_1596_amplicon_samples_env_info.tsv

#We need to clean the ids since they have both SRSs and SRRs, we are keeping
#SRSs (field 1). We are prioritizing biological samples
cut -f1 taxon_90_1596_amplicon_samples_env_info.tsv | cut -d '.' -f1 > taxon_90_1596_amplicon_samples_srrs_clean.txt

#Finally, let's filter our taxon tsv to retain amplicon samples only
grep -Ff taxon_90_1596_amplicon_samples_srrs_clean.txt taxon_90_1596_samples.tsv > taxon_90_1596_amplicon_samples.tsv

#If you are working with lists from multiple taxons, it could be useful to merge all lists
#for further analyses (BLASTS, downloading samples...)
cat taxon_90_128_amplicon_samples.tsv taxon_90_143_amplicon_samples.tsv taxon_90_1596_amplicon_samples.tsv | sort -t ',' -k1,1 | awk -F ',' '!seen[$1]++' > taxon_all_amplicon_samples.tsv

#we need to remove samples from those projects already mined with IMNGS, so we extract the BioProject Accessions 
cut -d ',' -f16 imngs_blast_assigned_metadata_classified.csv | uniq | awk 'gsub(/"/,"",$0)'> imngs_matched_bps.txt

#Didn't work, grep the list of srrs in the file, extract SRPS and save them as a list
grep -Ff imngs_matched_srrs_clean.txt taxon_all_amplicon_samples.tsv | cut -f8 |
uniq > imngs_matched_srps.txt

#we use this list running this command
grep -vFf imngs_matched_srps.txt taxon_all_amplicon_samples.tsv > taxon_all_amplicon_samples_wo_IMNGS.tsv

#we also check that the samples from Yucatan to be analysed are not in the MAP final list

#pool all the SRR samples id
cat py_dsbb/py_dsbb_srr_ids_ok.txt celestun_dsbb/celestun_dsbb_srrs.txt > yucatan_dsbb_srr_ids.txt

#and grep the resulting list
grep -vFf yucatan_dsbb_srr_ids.txt taxon_all_amplicon_samples_wo_IMNGS.tsv > taxon_all_amplicon_samples_ok.tsv

###
## For counting the number of BioSamples (DRSs, ERSs, SRSs) represented in this dataset, run this
cut -f1 file.tsv | uniq | wc  -l


## For counting the number of runs (DRRs, ERRs, SRRs), 
cut -f2 file.tsv | uniq | wc  -l

#For counting the number of BioProjects (PRJNAs, SAMNs, DRPs, ERPs, SRPs)
cut  -f8 filelak.csv | uniq | wc  -l

###
## Retriving BioSamples IDs (DRSs, ERSs, SRSs) only
cut -f1 taxon_all_amplicon_samples_ok.tsv | uniq > taxon_all_amplicon_samples_MAP_dsbb.txt