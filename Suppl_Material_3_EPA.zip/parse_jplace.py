#!/usr/bin/env python3
"""
Parse an EPA-ng .jplace file and extract, per query sequence, the
placement branch (edge_num) and likelihood weight ratio (LWR).

Usage:
    python parse_jplace.py input.jplace output.tsv [--best-only]

Options:
    --best-only   Keep only the highest-LWR placement per query
                  (default: keep all placements per query)
"""

import json
import re
import csv
import argparse


# ---------------------------------------------------------------------------
# Newick parsing: jplace trees embed the edge number for every branch as
# "{N}" right after the branch length, e.g. "Ca_Electrothrix_sp_AR5:0.0007{90}"
# for a leaf, or ")95:0.05{3}" for an internal branch. Standard newick
# parsers don't understand the "{N}" part, so we parse it ourselves.
# ---------------------------------------------------------------------------

def parse_newick(tree_str):
    s = tree_str.strip().rstrip(';')
    pos = [0]

    def parse_node():
        node = {'children': [], 'name': None, 'edge_num': None}
        if s[pos[0]] == '(':
            pos[0] += 1
            while True:
                node['children'].append(parse_node())
                if s[pos[0]] == ',':
                    pos[0] += 1
                    continue
                elif s[pos[0]] == ')':
                    pos[0] += 1
                    break
        label_start = pos[0]
        while pos[0] < len(s) and s[pos[0]] not in ',()':
            pos[0] += 1
        annotation = s[label_start:pos[0]]
        # matches: name (optional), ":branch_length" (optional), "{edge_num}" (optional)
        m = re.match(r'^([^:{}]*)?(?::([\d.eE+-]+))?(?:\{(\d+)\})?$', annotation)
        if m:
            name, _branch_len, edge = m.groups()
            node['name'] = name if name else None
            node['edge_num'] = int(edge) if edge is not None else None
        return node

    return parse_node()


def _collect_leaves(node, leaves):
    if not node['children']:
        if node['name']:
            leaves.append(node['name'])
    else:
        for c in node['children']:
            _collect_leaves(c, leaves)
    return leaves


def build_edge_map(tree_str):
    """Return {edge_num: {'is_leaf': bool, 'name': str or None,
                           'descendant_leaves': [names]}}"""
    root = parse_newick(tree_str)
    edge_map = {}

    def walk(node):
        is_leaf = len(node['children']) == 0
        if node['edge_num'] is not None:
            edge_map[node['edge_num']] = {
                'is_leaf': is_leaf,
                'name': node['name'] if is_leaf else None,
                'descendant_leaves': _collect_leaves(node, []),
            }
        for c in node['children']:
            walk(c)

    walk(root)
    return edge_map


def parse_jplace(path, best_only=False):
    with open(path) as f:
        data = json.load(f)

    # 'fields' tells us the column order inside each placement's 'p' list,
    # e.g. ["edge_num", "likelihood", "like_weight_ratio",
    #       "distal_length", "pendant_length"]
    fields = data["fields"]
    edge_idx = fields.index("edge_num")
    lwr_idx = fields.index("like_weight_ratio")

    edge_map = build_edge_map(data["tree"])

    rows = []
    for placement in data["placements"]:
        # query name(s) can be under "n" (list of names) or "nm"
        # (list of [name, multiplicity] pairs)
        if "n" in placement:
            names = placement["n"]
        else:
            names = [nm[0] for nm in placement["nm"]]

        placements = placement["p"]
        if best_only:
            placements = [max(placements, key=lambda p: p[lwr_idx])]

        for name in names:
            for p in placements:
                edge_num = p[edge_idx]
                info = edge_map.get(edge_num, {})
                if info.get('is_leaf'):
                    edge_taxon = info['name']
                elif info.get('descendant_leaves'):
                    # internal branch: no single sequence, report descendant
                    # leaves of that clade instead
                    edge_taxon = "internal:" + ",".join(info['descendant_leaves'])
                else:
                    edge_taxon = None

                rows.append({
                    "query": name,
                    "edge_num": edge_num,
                    "LWR": p[lwr_idx],
                    "edge_taxon": edge_taxon,
                })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="input .jplace file")
    ap.add_argument("output", help="output .tsv file")
    ap.add_argument("--best-only", action="store_true",
                     help="keep only the best (highest LWR) placement per query")
    args = ap.parse_args()

    rows = parse_jplace(args.input, best_only=args.best_only)

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["query", "edge_num", "LWR", "edge_taxon"], delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows to {args.output}")


if __name__ == "__main__":
    main()
